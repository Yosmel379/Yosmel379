This repository contains a full digital biological simulation.
It does NOT represent real biological life.
It is intended for scientific modeling, education, and hypothesis testing.
